function rslt = terminal(TT, U)
%marks all terminal states: states TT, network F, payoffs U

n = size(TT,1);
str_term_TT = str_terminal(TT);
term_TT = 2*str_term_TT-1; %if we haven't marked a state yet, then it is -1

max_u = max(U(:, str_term_TT==1),[],2);

for ii = 1:n-1;
    jj = n-ii; %number of informed agents/this is an index for backward induction
    
    for kk = 1:length(TT);
        if (sum(TT(:,kk)) == jj) %select a state (kk) with jj informed agents
            term_TT(1,kk) = 0; %mark it as transitory for now
            if all(U((TT(:,kk)==1),kk)>= max_u((TT(:,kk)==1),1)) %if all informed agents in state (kk) get more then they can get in their best terminal state, mark (kk) as terminal
                term_TT(1,kk) = 1;%update term_TT
            end;
        end;
    end;
    
    max_u = max(U(:, term_TT==1),[],2); %update the best payoff that can be obtained in terminal states
end;
rslt = term_TT+str_term_TT; %1 is terminal, 2 if str. terminal
return;

