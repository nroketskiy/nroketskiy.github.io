%This is an counterexample with nonlinear preferences: connecting two
%informed agents makes them both worse off.
close all;
clear all;
clc;


n =11;
u = zeros(n,1);
for ii = 1:n;
    u(ii) = n-ii;
end;

phi = 1.8; 

F = zeros(n,n);
F(3,4) = 1;
F(1,2) = 1;
F(1,5) = 1;
F(2,3) = 1;
F(4,5) = 1;
F(5,6) = 1;
F(5,7) = 1;
F(5,8) = 1;
F(1,9) = 1;
F(1,10) = 1;
F(1,11) = 1;
F = triu(F,1);
F = F+F';

oo = [3];
TT = allstates_O(n,oo);
U = utility_linear(F, TT, u, phi);
plot_terminal_O(F, U, oo, 11)

oo = [1];
TT = allstates_O(n,oo);
U = utility_linear(F, TT, u, phi);
plot_terminal_O(F, U, oo, 12)

oo = [1;5];
TT = allstates_O(n,oo);
U = utility_linear(F, TT, u, phi);
plot_terminal_O(F, U, oo, 13)
