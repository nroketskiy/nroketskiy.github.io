function [TT_fin U_max] = equilibrium_o(TT, U, term, o)
%this function selects the best terminal outcome from the point of view of
%agent o\in O. If agent o is one of the originators, than this forecast is
%a valid value for mu(O) for some forecast mu. Moreover, if this function
%is run for all o in O, we get mu(O) for all possible mu.
[n,K] = size(TT);

%TT_origin = TT(:,sum(TT)== 1);

TT_fin = zeros(n,1);

%U = utility(F, TT, u, phi); %vector of utilities for all agents in all states
U_max = min(min(U))-1; %setting up the search for the largest utility

for kk = 1:K;
    if term(kk)>0; %check if state indexed by kk is terminal
        if (U(o,kk)>=U_max) %maximizing utility of originator jj
            TT_fin = TT(:,kk);
            U_max = U(o,kk);
        end;
    end;
end;

return;

