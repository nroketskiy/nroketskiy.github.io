%this is an illustration of multiplicity for mutliple originators
close all;
clear all;
clc;
%parameters
n = 11;

u = zeros(n,1);
for ii = 1:n;
    u(ii) = -ii;
end;

phi =2.5;
F7 = zeros(n,n);
F7(1,2) = 1;
F7(1,9) = 1;
F7(2,3) = 1;
F7(2,4) = 1;
F7(2,5) = 1;
F7(6,9) = 1;
F7(7,9) = 1;
F7(8,9) = 1;
F7(2,11) = 1;
%F7(8,10) = 1;
F7(9,11) = 1;
F7(1,10) = 1;
F7(4,6) = 1;
F7 = triu(F7,1);
F7 = F7+F7';

oo = [3;9];

TT = allstates_O(n,oo);
U = utility_linear(F7, TT, u, phi);

plot_terminal_O(F7, U, oo, 666)

