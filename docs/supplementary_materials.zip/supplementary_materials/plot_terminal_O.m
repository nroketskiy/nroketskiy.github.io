function plot_terminal_O(F, U, oo, task_id)
%plots mu(oo)

n = length(F);


TT = allstates_O(n,oo);
term = terminal(TT, U);

figure(task_id);
ii=(1:n)';
radius = ones(n,1)-0.5*(n>9)*((ii==1)+(ii==5)+(ii==9)+(ii==13));
xy = [radius.*cos(2*pi*ii/n) radius.*sin(2*pi*ii/n)];


for jj = 1:length(oo);
    
    [TT_fin U_max] = equilibrium_o(TT, U, term, oo(jj));
    
    dim1_subplots = ceil(length(oo)/ceil(length(oo)^0.5));
    dim2_subplots = ceil(length(oo)/dim1_subplots);
    
    subplot(dim1_subplots,dim2_subplots,jj);
    
    gplot(F,xy);
    axis([-1.2 1.2 -1.2 1.2]);
    axis equal;
    axis off;
    hold on;
    plot(xy(:,1),xy(:,2),'o','LineWidth',1,'MarkerEdgeColor','b',...
        'MarkerFaceColor','w','MarkerSize',5);
    
    xy_origin = xy(oo,:);
    xy_fin = xy(TT_fin(:)==1,:);
    
    plot(xy_fin(:,1),xy_fin(:,2),'o','LineWidth',1,'MarkerEdgeColor','b',...
        'MarkerFaceColor','b','MarkerSize',5);
    plot(xy_origin(:,1),xy_origin(:,2),'o','LineWidth',1,'MarkerEdgeColor','b',...
        'MarkerFaceColor','r','MarkerSize',5);
end;

code=['save rslt_' num2str(task_id) '.mat'];
eval(code);

hold off

return;

