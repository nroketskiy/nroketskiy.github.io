function rslt = allstates(n)
%computes all states of the model (all sets of informed agents, not trees)
%this is valid only when preferences satisfy A1
%rslt is a vector of size(n by 2^n-1)
rslttmp = zeros(n, 2^n-1);
for ii = 1:2^n-1;
    rslttmp(:,ii) = str2num(dec2bin(ii,n)');
end;
rslt = rslttmp;

return;