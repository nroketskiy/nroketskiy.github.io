function rslt = allstates_O(n,oo)
%computes all states of the game (all sets of informed agents) given the
%SET of originators oo
%rslt is a smaller vector than the one produced by allstates function
rslttmp = zeros(n, 2^n-1);
include_state = zeros(1,2^n-1);
for ii = 1:2^n-1;
    rslttmp(:,ii) = str2num(dec2bin(ii,n)');
    if rslttmp(oo,ii)==1
        include_state(1,ii) = 1;
    end; 
end;
rslt = rslttmp(:,(include_state>0));

return;