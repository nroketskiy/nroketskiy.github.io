function rslt = utility_multiplicative(F, TT, u, phi);
%computes the vector of utilities of all agents in F in outcome T. 

%F is a matrix of friendship (n by n) and T is the vector of informed agents
%(n by 1)(can be redone into the tree of information flows).

%u is the vector of values for the secret, for example u(1) is the value of
%the secret if it is know by 1 agent.

%phi is the degree of altruism, 0<phi<1

%rslt is a vector (n by 1)
[n, m] = size(F);
tmp = (TT.*repmat(u(sum(TT))', [n 1]))+phi*log(F'*TT);%nonlinear (log) version
max_u = max(tmp(:));
rslt = tmp+666*abs(max_u)*(TT-1);%nobody wants to be uninformed hence penalty of 666 times the highest utility in the model;

return;

