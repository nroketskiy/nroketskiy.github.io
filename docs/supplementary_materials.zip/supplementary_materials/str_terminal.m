function rslt = str_terminal(TT)
%marks all strongly terminal states (starting points for BI).
%this can be improved to speed up the main algorithm
n = size(TT,1);
rslt = (sum(TT)== n); %could use a stronger condition here for large n
return;

