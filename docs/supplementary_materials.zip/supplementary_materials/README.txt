This is a collection of MATLAB code that produces examples for "Circles of Trust: Social Networks and Rival Information" by Persson (r) Roketskiy (r) Lee (2021).

To replicate the results, run illu_*.m files.


