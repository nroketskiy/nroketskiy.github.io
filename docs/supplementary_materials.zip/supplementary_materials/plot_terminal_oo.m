function plot_terminal_oo(F, U, oo, task_id)
%plots everything in plot k
%U = utility(F, TT, u, phi);

n = length(F);
F = triu(F,1);
F = F+F';

TT = allstates_o(n,oo);

term = terminal(F, TT, u, phi);
[TT_origin TT_fin U_fin] = equilibrium(F, TT, u, phi, term);

%ploting a graph
figure(task_id);


ii=(1:n)';
radius = ones(n,1)-0.5*(n>9)*((ii==1)+(ii==5)+(ii==9)+(ii==13));
xy = [radius.*cos(2*pi*ii/n) radius.*sin(2*pi*ii/n)];
for jj = 1:n;
    subplot(3,ceil(n/3),jj);
    
    gplot(F,xy);
    axis([-1.2 1.2 -1.2 1.2]);
    axis equal;
    axis off;
    hold on;
    plot(xy(:,1),xy(:,2),'o','LineWidth',1,'MarkerEdgeColor','b',...
        'MarkerFaceColor','w','MarkerSize',5);
    
    xy_origin = xy(TT_origin(:,jj)==1,:);
    xy_fin = xy(TT_fin(:,jj)==1,:);
    
    plot(xy_fin(:,1),xy_fin(:,2),'o','LineWidth',1,'MarkerEdgeColor','b',...
        'MarkerFaceColor','b','MarkerSize',5);
    plot(xy_origin(:,1),xy_origin(:,2),'o','LineWidth',1,'MarkerEdgeColor','b',...
        'MarkerFaceColor','r','MarkerSize',5);
    title(['\phi=' num2str(phi)]);
end;

code=['save rslt_' num2str(task_id) '.mat'];
eval(code);

hold off

return;

