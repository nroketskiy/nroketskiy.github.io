%This is an counterexample with nonlinear preferences: connecting two
%informed agents makes them both worse off.
close all;
clear all;
clc;


n =6;
u = zeros(n,1);
for ii = 1:n;
    u(ii) = n-ii;
end;

phi = 3; 

F = zeros(n,n);
F(1,2) = 1;
F(1,5) = 1;
F(5,6) = 1;
F(2,3) = 1;
F(3,4) = 1;
F(4,5) = 1;
F = triu(F,1);
F = F+F';

oo = [5];
TT = allstates_O(n,oo);
U = utility_multiplicative(F, TT, u, phi);

plot_terminal_O(F, U, oo, 11)

F(1,4) = 1/3;
F = triu(F,1);
F = F+F';

U = utility_multiplicative(F, TT, u, phi);
plot_terminal_O(F, U, oo, 12)
