function [TT_origin TT_fin U_fin] = equilibrium(F, TT, u, phi, term)
%finds mu(o) for all o

[n, m] = size(F);

TT_origin = TT(:,sum(TT)== 1);

TT_fin = TT_origin;

U = utility(F, TT, u, phi); %vector of utilities for all agents in all states
U_max = U(:,sum(TT)== 1); %vector of utilities for originators in their initial states

U_fin = U_max;

for kk = 1:length(TT);
    if term(kk)>0; %check if state indexed by kk is terminal
        for jj = 1:n;
            if (U((TT_origin(:,jj)==1),kk)>=U_max((TT_origin(:,jj)==1),jj)) %maximizing utility of originator jj
                TT_fin(:,jj) = TT(:,kk);
                U_max((TT_origin(:,jj)==1),jj) = U((TT_origin(:,jj)==1),kk); 
                U_fin(:,jj) = U(:,kk);
            end;
        end;
    end;
end;

return;

